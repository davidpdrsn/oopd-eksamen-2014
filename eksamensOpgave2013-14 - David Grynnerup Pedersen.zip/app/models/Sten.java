package app.models;

/**
 * A stone.
 */
public class Sten extends Entity {
  /**
   * Check if the entity is a stone or not. This is always true.
   * @return whether its a stone or not.
   */
  public boolean isSten() {
    return true;
  }
}
