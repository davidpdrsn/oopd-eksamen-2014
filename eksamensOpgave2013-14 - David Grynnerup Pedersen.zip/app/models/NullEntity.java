package app.models;

// TODO: is this really required?
/**
 * A null or empty entity.
 */
public class NullEntity extends Entity {
  /**
   * Check if an entity is a null entity.
   */
  public boolean isNullEntity() {
    return true;
  }
}
